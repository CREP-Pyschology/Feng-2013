﻿/******************************** 
 * Feng_Mindwandering_Set1 Test *
 ********************************/

// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0, 0, 0]),
  units: 'height',
  waitBlanking: true
});

// store info about the experiment session:
let expName = 'Feng_Mindwandering_Set1';  // from the Builder filename that created this script
let expInfo = {'participant': ''};

// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(WelcomeRoutineBegin());
flowScheduler.add(WelcomeRoutineEachFrame());
flowScheduler.add(WelcomeRoutineEnd());
const task_instr_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(task_instr_loopLoopBegin, task_instr_loopLoopScheduler);
flowScheduler.add(task_instr_loopLoopScheduler);
flowScheduler.add(task_instr_loopLoopEnd);
const passage1_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage1_loopLoopBegin, passage1_loopLoopScheduler);
flowScheduler.add(passage1_loopLoopScheduler);
flowScheduler.add(passage1_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension1_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension1_loopLoopBegin, comprehension1_loopLoopScheduler);
flowScheduler.add(comprehension1_loopLoopScheduler);
flowScheduler.add(comprehension1_loopLoopEnd);
const passage2_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage2_loopLoopBegin, passage2_loopLoopScheduler);
flowScheduler.add(passage2_loopLoopScheduler);
flowScheduler.add(passage2_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension2_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension2_loopLoopBegin, comprehension2_loopLoopScheduler);
flowScheduler.add(comprehension2_loopLoopScheduler);
flowScheduler.add(comprehension2_loopLoopEnd);
const passage3_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage3_loopLoopBegin, passage3_loopLoopScheduler);
flowScheduler.add(passage3_loopLoopScheduler);
flowScheduler.add(passage3_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension3_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension3_loopLoopBegin, comprehension3_loopLoopScheduler);
flowScheduler.add(comprehension3_loopLoopScheduler);
flowScheduler.add(comprehension3_loopLoopEnd);
const passage4_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage4_loopLoopBegin, passage4_loopLoopScheduler);
flowScheduler.add(passage4_loopLoopScheduler);
flowScheduler.add(passage4_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension4_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension4_loopLoopBegin, comprehension4_loopLoopScheduler);
flowScheduler.add(comprehension4_loopLoopScheduler);
flowScheduler.add(comprehension4_loopLoopEnd);
const passage5_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage5_loopLoopBegin, passage5_loopLoopScheduler);
flowScheduler.add(passage5_loopLoopScheduler);
flowScheduler.add(passage5_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension5_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension5_loopLoopBegin, comprehension5_loopLoopScheduler);
flowScheduler.add(comprehension5_loopLoopScheduler);
flowScheduler.add(comprehension5_loopLoopEnd);
const passage6_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage6_loopLoopBegin, passage6_loopLoopScheduler);
flowScheduler.add(passage6_loopLoopScheduler);
flowScheduler.add(passage6_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension6_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension6_loopLoopBegin, comprehension6_loopLoopScheduler);
flowScheduler.add(comprehension6_loopLoopScheduler);
flowScheduler.add(comprehension6_loopLoopEnd);
const passage7_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage7_loopLoopBegin, passage7_loopLoopScheduler);
flowScheduler.add(passage7_loopLoopScheduler);
flowScheduler.add(passage7_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension7_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension7_loopLoopBegin, comprehension7_loopLoopScheduler);
flowScheduler.add(comprehension7_loopLoopScheduler);
flowScheduler.add(comprehension7_loopLoopEnd);
const passage8_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(passage8_loopLoopBegin, passage8_loopLoopScheduler);
flowScheduler.add(passage8_loopLoopScheduler);
flowScheduler.add(passage8_loopLoopEnd);
flowScheduler.add(Compr_instrRoutineBegin());
flowScheduler.add(Compr_instrRoutineEachFrame());
flowScheduler.add(Compr_instrRoutineEnd());
const comprehension8_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(comprehension8_loopLoopBegin, comprehension8_loopLoopScheduler);
flowScheduler.add(comprehension8_loopLoopScheduler);
flowScheduler.add(comprehension8_loopLoopEnd);
flowScheduler.add(ThankYouRoutineBegin());
flowScheduler.add(ThankYouRoutineEachFrame());
flowScheduler.add(ThankYouRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  });


var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2020.1.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls(('http://brunellifesc.eu.qualtrics.com/jfe/form/SV_2ufZkUl5twQ0JOB?participant=' + expInfo['participant']), 'https://www.brunel.ac.uk/people/bianca-de-haan');

  return Scheduler.Event.NEXT;
}


var WelcomeClock;
var welcome_text;
var Task_intrClock;
var taskinstr_text;
var taskinstr_resp;
var SentenceClock;
var sentence_text;
var sentence_resp;
var ProbeClock;
var probe_text;
var probe_resp;
var Compr_instrClock;
var compr_instr_text;
var compr_instr_resp;
var ComprehensionClock;
var comprehension_text;
var comprehension_resp;
var ThankYouClock;
var Thankyou_text;
var Thankyou_resp;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "Welcome"
  WelcomeClock = new util.Clock();
  welcome_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'welcome_text',
    text: 'Welcome to this study!',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Initialize components for Routine "Task_intr"
  Task_intrClock = new util.Clock();
  taskinstr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'taskinstr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.03,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  taskinstr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Sentence"
  SentenceClock = new util.Clock();
  sentence_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'sentence_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  sentence_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Probe"
  ProbeClock = new util.Clock();
  probe_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'probe_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  probe_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Compr_instr"
  Compr_instrClock = new util.Clock();
  compr_instr_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'compr_instr_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  compr_instr_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "Comprehension"
  ComprehensionClock = new util.Clock();
  comprehension_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'comprehension_text',
    text: 'default text',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  comprehension_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "ThankYou"
  ThankYouClock = new util.Clock();
  Thankyou_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Thankyou_text',
    text: 'Thank you for your participation in this study!\n\n\nMAKE SURE TO PRESS "OK" ON THE NEXT POP-UP MESSAGE TO BE REDIRECTED TO RECEIVE YOUR COMPLETION CODE!\n\n\nWithout this completion code, we will not be able to pay you for your time.\n\nPlease press the space bar',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  Thankyou_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var WelcomeComponents;
function WelcomeRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Welcome'-------
    t = 0;
    WelcomeClock.reset(); // clock
    frameN = -1;
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    WelcomeComponents = [];
    WelcomeComponents.push(welcome_text);
    
    WelcomeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


var frameRemains;
var continueRoutine;
function WelcomeRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Welcome'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = WelcomeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *welcome_text* updates
    if (t >= 0.0 && welcome_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcome_text.tStart = t;  // (not accounting for frame time here)
      welcome_text.frameNStart = frameN;  // exact frame index
      
      welcome_text.setAutoDraw(true);
    }

    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (welcome_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      welcome_text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    WelcomeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function WelcomeRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Welcome'-------
    WelcomeComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


var task_instr_loop;
var currentLoop;
function task_instr_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  task_instr_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Task_Instr.csv',
    seed: undefined, name: 'task_instr_loop'
  });
  psychoJS.experiment.addLoop(task_instr_loop); // add the loop to the experiment
  currentLoop = task_instr_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  task_instr_loop.forEach(function() {
    const snapshot = task_instr_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(Task_intrRoutineBegin(snapshot));
    thisScheduler.add(Task_intrRoutineEachFrame(snapshot));
    thisScheduler.add(Task_intrRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function task_instr_loopLoopEnd() {
  psychoJS.experiment.removeLoop(task_instr_loop);

  return Scheduler.Event.NEXT;
}


var passage1_loop;
function passage1_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage1_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage1_difficult.csv',
    seed: undefined, name: 'passage1_loop'
  });
  psychoJS.experiment.addLoop(passage1_loop); // add the loop to the experiment
  currentLoop = passage1_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage1_loop.forEach(function() {
    const snapshot = passage1_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage1_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage1_loop);

  return Scheduler.Event.NEXT;
}


var comprehension1_loop;
function comprehension1_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension1_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension1.csv',
    seed: undefined, name: 'comprehension1_loop'
  });
  psychoJS.experiment.addLoop(comprehension1_loop); // add the loop to the experiment
  currentLoop = comprehension1_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension1_loop.forEach(function() {
    const snapshot = comprehension1_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension1_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension1_loop);

  return Scheduler.Event.NEXT;
}


var passage2_loop;
function passage2_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage2_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage2_easy.csv',
    seed: undefined, name: 'passage2_loop'
  });
  psychoJS.experiment.addLoop(passage2_loop); // add the loop to the experiment
  currentLoop = passage2_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage2_loop.forEach(function() {
    const snapshot = passage2_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage2_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage2_loop);

  return Scheduler.Event.NEXT;
}


var comprehension2_loop;
function comprehension2_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension2_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension2.csv',
    seed: undefined, name: 'comprehension2_loop'
  });
  psychoJS.experiment.addLoop(comprehension2_loop); // add the loop to the experiment
  currentLoop = comprehension2_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension2_loop.forEach(function() {
    const snapshot = comprehension2_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension2_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension2_loop);

  return Scheduler.Event.NEXT;
}


var passage3_loop;
function passage3_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage3_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage3_difficult.csv',
    seed: undefined, name: 'passage3_loop'
  });
  psychoJS.experiment.addLoop(passage3_loop); // add the loop to the experiment
  currentLoop = passage3_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage3_loop.forEach(function() {
    const snapshot = passage3_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage3_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage3_loop);

  return Scheduler.Event.NEXT;
}


var comprehension3_loop;
function comprehension3_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension3_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension3.csv',
    seed: undefined, name: 'comprehension3_loop'
  });
  psychoJS.experiment.addLoop(comprehension3_loop); // add the loop to the experiment
  currentLoop = comprehension3_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension3_loop.forEach(function() {
    const snapshot = comprehension3_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension3_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension3_loop);

  return Scheduler.Event.NEXT;
}


var passage4_loop;
function passage4_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage4_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage4_easy.csv',
    seed: undefined, name: 'passage4_loop'
  });
  psychoJS.experiment.addLoop(passage4_loop); // add the loop to the experiment
  currentLoop = passage4_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage4_loop.forEach(function() {
    const snapshot = passage4_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage4_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage4_loop);

  return Scheduler.Event.NEXT;
}


var comprehension4_loop;
function comprehension4_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension4_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension4.csv',
    seed: undefined, name: 'comprehension4_loop'
  });
  psychoJS.experiment.addLoop(comprehension4_loop); // add the loop to the experiment
  currentLoop = comprehension4_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension4_loop.forEach(function() {
    const snapshot = comprehension4_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension4_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension4_loop);

  return Scheduler.Event.NEXT;
}


var passage5_loop;
function passage5_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage5_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage5_difficult.csv',
    seed: undefined, name: 'passage5_loop'
  });
  psychoJS.experiment.addLoop(passage5_loop); // add the loop to the experiment
  currentLoop = passage5_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage5_loop.forEach(function() {
    const snapshot = passage5_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage5_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage5_loop);

  return Scheduler.Event.NEXT;
}


var comprehension5_loop;
function comprehension5_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension5_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension5.csv',
    seed: undefined, name: 'comprehension5_loop'
  });
  psychoJS.experiment.addLoop(comprehension5_loop); // add the loop to the experiment
  currentLoop = comprehension5_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension5_loop.forEach(function() {
    const snapshot = comprehension5_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension5_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension5_loop);

  return Scheduler.Event.NEXT;
}


var passage6_loop;
function passage6_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage6_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage6_easy.csv',
    seed: undefined, name: 'passage6_loop'
  });
  psychoJS.experiment.addLoop(passage6_loop); // add the loop to the experiment
  currentLoop = passage6_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage6_loop.forEach(function() {
    const snapshot = passage6_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage6_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage6_loop);

  return Scheduler.Event.NEXT;
}


var comprehension6_loop;
function comprehension6_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension6_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension6.csv',
    seed: undefined, name: 'comprehension6_loop'
  });
  psychoJS.experiment.addLoop(comprehension6_loop); // add the loop to the experiment
  currentLoop = comprehension6_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension6_loop.forEach(function() {
    const snapshot = comprehension6_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension6_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension6_loop);

  return Scheduler.Event.NEXT;
}


var passage7_loop;
function passage7_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage7_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage7_difficult.csv',
    seed: undefined, name: 'passage7_loop'
  });
  psychoJS.experiment.addLoop(passage7_loop); // add the loop to the experiment
  currentLoop = passage7_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage7_loop.forEach(function() {
    const snapshot = passage7_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage7_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage7_loop);

  return Scheduler.Event.NEXT;
}


var comprehension7_loop;
function comprehension7_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension7_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension7.csv',
    seed: undefined, name: 'comprehension7_loop'
  });
  psychoJS.experiment.addLoop(comprehension7_loop); // add the loop to the experiment
  currentLoop = comprehension7_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension7_loop.forEach(function() {
    const snapshot = comprehension7_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension7_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension7_loop);

  return Scheduler.Event.NEXT;
}


var passage8_loop;
function passage8_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  passage8_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Passage8_easy.csv',
    seed: undefined, name: 'passage8_loop'
  });
  psychoJS.experiment.addLoop(passage8_loop); // add the loop to the experiment
  currentLoop = passage8_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  passage8_loop.forEach(function() {
    const snapshot = passage8_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(SentenceRoutineBegin(snapshot));
    thisScheduler.add(SentenceRoutineEachFrame(snapshot));
    thisScheduler.add(SentenceRoutineEnd(snapshot));
    thisScheduler.add(ProbeRoutineBegin(snapshot));
    thisScheduler.add(ProbeRoutineEachFrame(snapshot));
    thisScheduler.add(ProbeRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function passage8_loopLoopEnd() {
  psychoJS.experiment.removeLoop(passage8_loop);

  return Scheduler.Event.NEXT;
}


var comprehension8_loop;
function comprehension8_loopLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  comprehension8_loop = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'Comprehension8.csv',
    seed: undefined, name: 'comprehension8_loop'
  });
  psychoJS.experiment.addLoop(comprehension8_loop); // add the loop to the experiment
  currentLoop = comprehension8_loop;  // we're now the current loop

  // Schedule all the trials in the trialList:
  comprehension8_loop.forEach(function() {
    const snapshot = comprehension8_loop.getSnapshot();

    thisScheduler.add(importConditions(snapshot));
    thisScheduler.add(ComprehensionRoutineBegin(snapshot));
    thisScheduler.add(ComprehensionRoutineEachFrame(snapshot));
    thisScheduler.add(ComprehensionRoutineEnd(snapshot));
    thisScheduler.add(endLoopIteration(thisScheduler, snapshot));
  });

  return Scheduler.Event.NEXT;
}


function comprehension8_loopLoopEnd() {
  psychoJS.experiment.removeLoop(comprehension8_loop);

  return Scheduler.Event.NEXT;
}


var _taskinstr_resp_allKeys;
var Task_intrComponents;
function Task_intrRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Task_intr'-------
    t = 0;
    Task_intrClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    taskinstr_text.setText(instruct_text);
    taskinstr_resp.keys = undefined;
    taskinstr_resp.rt = undefined;
    _taskinstr_resp_allKeys = [];
    // keep track of which components have finished
    Task_intrComponents = [];
    Task_intrComponents.push(taskinstr_text);
    Task_intrComponents.push(taskinstr_resp);
    
    Task_intrComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function Task_intrRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Task_intr'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = Task_intrClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *taskinstr_text* updates
    if (t >= 0.0 && taskinstr_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      taskinstr_text.tStart = t;  // (not accounting for frame time here)
      taskinstr_text.frameNStart = frameN;  // exact frame index
      
      taskinstr_text.setAutoDraw(true);
    }

    
    // *taskinstr_resp* updates
    if (t >= 0.0 && taskinstr_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      taskinstr_resp.tStart = t;  // (not accounting for frame time here)
      taskinstr_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { taskinstr_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { taskinstr_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { taskinstr_resp.clearEvents(); });
    }

    if (taskinstr_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = taskinstr_resp.getKeys({keyList: ['space'], waitRelease: false});
      _taskinstr_resp_allKeys = _taskinstr_resp_allKeys.concat(theseKeys);
      if (_taskinstr_resp_allKeys.length > 0) {
        taskinstr_resp.keys = _taskinstr_resp_allKeys[_taskinstr_resp_allKeys.length - 1].name;  // just the last key pressed
        taskinstr_resp.rt = _taskinstr_resp_allKeys[_taskinstr_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    Task_intrComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Task_intrRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Task_intr'-------
    Task_intrComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('taskinstr_resp.keys', taskinstr_resp.keys);
    if (typeof taskinstr_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('taskinstr_resp.rt', taskinstr_resp.rt);
        routineTimer.reset();
        }
    
    taskinstr_resp.stop();
    // the Routine "Task_intr" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _sentence_resp_allKeys;
var SentenceComponents;
function SentenceRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Sentence'-------
    t = 0;
    SentenceClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    sentence_text.setText(line_text);
    sentence_resp.keys = undefined;
    sentence_resp.rt = undefined;
    _sentence_resp_allKeys = [];
    // keep track of which components have finished
    SentenceComponents = [];
    SentenceComponents.push(sentence_text);
    SentenceComponents.push(sentence_resp);
    
    SentenceComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function SentenceRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Sentence'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = SentenceClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *sentence_text* updates
    if (t >= 0.0 && sentence_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sentence_text.tStart = t;  // (not accounting for frame time here)
      sentence_text.frameNStart = frameN;  // exact frame index
      
      sentence_text.setAutoDraw(true);
    }

    
    // *sentence_resp* updates
    if (t >= 0.0 && sentence_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sentence_resp.tStart = t;  // (not accounting for frame time here)
      sentence_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { sentence_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { sentence_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { sentence_resp.clearEvents(); });
    }

    if (sentence_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = sentence_resp.getKeys({keyList: ['space'], waitRelease: false});
      _sentence_resp_allKeys = _sentence_resp_allKeys.concat(theseKeys);
      if (_sentence_resp_allKeys.length > 0) {
        sentence_resp.keys = _sentence_resp_allKeys[0].name;  // just the first key pressed
        sentence_resp.rt = _sentence_resp_allKeys[0].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    SentenceComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function SentenceRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Sentence'-------
    SentenceComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('sentence_resp.keys', sentence_resp.keys);
    if (typeof sentence_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('sentence_resp.rt', sentence_resp.rt);
        routineTimer.reset();
        }
    
    sentence_resp.stop();
    // the Routine "Sentence" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _probe_resp_allKeys;
var ProbeComponents;
function ProbeRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Probe'-------
    t = 0;
    ProbeClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    probe_text.setText('Where you mind wandering when you read the previous sentence?\n\nPress Y for yes, or N for no');
    probe_resp.keys = undefined;
    probe_resp.rt = undefined;
    _probe_resp_allKeys = [];
    // keep track of which components have finished
    ProbeComponents = [];
    ProbeComponents.push(probe_text);
    ProbeComponents.push(probe_resp);
    
    ProbeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function ProbeRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Probe'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = ProbeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    if ((probe !== 1)) {
        continueRoutine = false;
    }
    
    
    // *probe_text* updates
    if (t >= 0.0 && probe_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      probe_text.tStart = t;  // (not accounting for frame time here)
      probe_text.frameNStart = frameN;  // exact frame index
      
      probe_text.setAutoDraw(true);
    }

    
    // *probe_resp* updates
    if (t >= 0.0 && probe_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      probe_resp.tStart = t;  // (not accounting for frame time here)
      probe_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { probe_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { probe_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { probe_resp.clearEvents(); });
    }

    if (probe_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = probe_resp.getKeys({keyList: ['y', 'n'], waitRelease: false});
      _probe_resp_allKeys = _probe_resp_allKeys.concat(theseKeys);
      if (_probe_resp_allKeys.length > 0) {
        probe_resp.keys = _probe_resp_allKeys[0].name;  // just the first key pressed
        probe_resp.rt = _probe_resp_allKeys[0].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ProbeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ProbeRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Probe'-------
    ProbeComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('probe_resp.keys', probe_resp.keys);
    if (typeof probe_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('probe_resp.rt', probe_resp.rt);
        routineTimer.reset();
        }
    
    probe_resp.stop();
    // the Routine "Probe" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _compr_instr_resp_allKeys;
var Compr_instrComponents;
function Compr_instrRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Compr_instr'-------
    t = 0;
    Compr_instrClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    compr_instr_text.setText('Now you will take the reading comprehension test for the passage you just read. The questions are in multiple choice format, you will use the letters a through e on your keyboard to answer. The test is self-paced. \n\nPlease press the space bar to continue.');
    compr_instr_resp.keys = undefined;
    compr_instr_resp.rt = undefined;
    _compr_instr_resp_allKeys = [];
    // keep track of which components have finished
    Compr_instrComponents = [];
    Compr_instrComponents.push(compr_instr_text);
    Compr_instrComponents.push(compr_instr_resp);
    
    Compr_instrComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function Compr_instrRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Compr_instr'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = Compr_instrClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *compr_instr_text* updates
    if (t >= 0.0 && compr_instr_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      compr_instr_text.tStart = t;  // (not accounting for frame time here)
      compr_instr_text.frameNStart = frameN;  // exact frame index
      
      compr_instr_text.setAutoDraw(true);
    }

    
    // *compr_instr_resp* updates
    if (t >= 0.0 && compr_instr_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      compr_instr_resp.tStart = t;  // (not accounting for frame time here)
      compr_instr_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { compr_instr_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { compr_instr_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { compr_instr_resp.clearEvents(); });
    }

    if (compr_instr_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = compr_instr_resp.getKeys({keyList: ['space'], waitRelease: false});
      _compr_instr_resp_allKeys = _compr_instr_resp_allKeys.concat(theseKeys);
      if (_compr_instr_resp_allKeys.length > 0) {
        compr_instr_resp.keys = _compr_instr_resp_allKeys[0].name;  // just the first key pressed
        compr_instr_resp.rt = _compr_instr_resp_allKeys[0].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    Compr_instrComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function Compr_instrRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Compr_instr'-------
    Compr_instrComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('compr_instr_resp.keys', compr_instr_resp.keys);
    if (typeof compr_instr_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('compr_instr_resp.rt', compr_instr_resp.rt);
        routineTimer.reset();
        }
    
    compr_instr_resp.stop();
    // the Routine "Compr_instr" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _comprehension_resp_allKeys;
var ComprehensionComponents;
function ComprehensionRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'Comprehension'-------
    t = 0;
    ComprehensionClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    comprehension_text.setAlignHoriz('left')
    comprehension_text.setText(line_text);
    comprehension_resp.keys = undefined;
    comprehension_resp.rt = undefined;
    _comprehension_resp_allKeys = [];
    // keep track of which components have finished
    ComprehensionComponents = [];
    ComprehensionComponents.push(comprehension_text);
    ComprehensionComponents.push(comprehension_resp);
    
    ComprehensionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function ComprehensionRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'Comprehension'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = ComprehensionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *comprehension_text* updates
    if (t >= 0.0 && comprehension_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      comprehension_text.tStart = t;  // (not accounting for frame time here)
      comprehension_text.frameNStart = frameN;  // exact frame index
      
      comprehension_text.setAutoDraw(true);
    }

    
    // *comprehension_resp* updates
    if (t >= 0.0 && comprehension_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      comprehension_resp.tStart = t;  // (not accounting for frame time here)
      comprehension_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { comprehension_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { comprehension_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { comprehension_resp.clearEvents(); });
    }

    if (comprehension_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = comprehension_resp.getKeys({keyList: ['a', 'b', 'c', 'd', 'e'], waitRelease: false});
      _comprehension_resp_allKeys = _comprehension_resp_allKeys.concat(theseKeys);
      if (_comprehension_resp_allKeys.length > 0) {
        comprehension_resp.keys = _comprehension_resp_allKeys[0].name;  // just the first key pressed
        comprehension_resp.rt = _comprehension_resp_allKeys[0].rt;
        // was this correct?
        if (comprehension_resp.keys == correct_response) {
            comprehension_resp.corr = 1;
        } else {
            comprehension_resp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ComprehensionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ComprehensionRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'Comprehension'-------
    ComprehensionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (comprehension_resp.keys === undefined) {
      if (['None','none',undefined].includes(correct_response)) {
         comprehension_resp.corr = 1;  // correct non-response
      } else {
         comprehension_resp.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for thisExp (ExperimentHandler)
    psychoJS.experiment.addData('comprehension_resp.keys', comprehension_resp.keys);
    psychoJS.experiment.addData('comprehension_resp.corr', comprehension_resp.corr);
    if (typeof comprehension_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('comprehension_resp.rt', comprehension_resp.rt);
        routineTimer.reset();
        }
    
    comprehension_resp.stop();
    // the Routine "Comprehension" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _Thankyou_resp_allKeys;
var ThankYouComponents;
function ThankYouRoutineBegin(trials) {
  return function () {
    //------Prepare to start Routine 'ThankYou'-------
    t = 0;
    ThankYouClock.reset(); // clock
    frameN = -1;
    // update component parameters for each repeat
    Thankyou_resp.keys = undefined;
    Thankyou_resp.rt = undefined;
    _Thankyou_resp_allKeys = [];
    // keep track of which components have finished
    ThankYouComponents = [];
    ThankYouComponents.push(Thankyou_text);
    ThankYouComponents.push(Thankyou_resp);
    
    ThankYouComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    
    return Scheduler.Event.NEXT;
  };
}


function ThankYouRoutineEachFrame(trials) {
  return function () {
    //------Loop for each frame of Routine 'ThankYou'-------
    let continueRoutine = true; // until we're told otherwise
    // get current time
    t = ThankYouClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *Thankyou_text* updates
    if (t >= 0.0 && Thankyou_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Thankyou_text.tStart = t;  // (not accounting for frame time here)
      Thankyou_text.frameNStart = frameN;  // exact frame index
      
      Thankyou_text.setAutoDraw(true);
    }

    
    // *Thankyou_resp* updates
    if (t >= 0.0 && Thankyou_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Thankyou_resp.tStart = t;  // (not accounting for frame time here)
      Thankyou_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { Thankyou_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { Thankyou_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { Thankyou_resp.clearEvents(); });
    }

    if (Thankyou_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = Thankyou_resp.getKeys({keyList: ['space'], waitRelease: false});
      _Thankyou_resp_allKeys = _Thankyou_resp_allKeys.concat(theseKeys);
      if (_Thankyou_resp_allKeys.length > 0) {
        Thankyou_resp.keys = _Thankyou_resp_allKeys[0].name;  // just the first key pressed
        Thankyou_resp.rt = _Thankyou_resp_allKeys[0].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ThankYouComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ThankYouRoutineEnd(trials) {
  return function () {
    //------Ending Routine 'ThankYou'-------
    ThankYouComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('Thankyou_resp.keys', Thankyou_resp.keys);
    if (typeof Thankyou_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('Thankyou_resp.rt', Thankyou_resp.rt);
        routineTimer.reset();
        }
    
    Thankyou_resp.stop();
    // the Routine "ThankYou" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(thisScheduler, loop) {
  // ------Prepare for next entry------
  return function () {
    if (typeof loop !== 'undefined') {
      // ------Check if user ended loop early------
      if (loop.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(loop);
        }
      thisScheduler.stop();
      } else {
        const thisTrial = loop.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(loop);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(trials) {
  return function () {
    psychoJS.importAttributes(trials.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  
  
  
  
  
  
  
  
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
